/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.soal1;

/**
 *
 * @author Hasby
 */
public class Soal1 {

    public static void main(String[] args) {
        byte angka1 = 125;
        byte angka2 = 6;
        byte hasil  = (byte) (angka1+angka2);
        System.out.println("Hasil 1"+hasil);
    }
}
